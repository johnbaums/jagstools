jagstools
=========

R functions to filter rjags object summaries.